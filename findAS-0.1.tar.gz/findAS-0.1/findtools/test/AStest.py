#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 2011 (thanks to Marco Galardini for some LOG!)
# GMPF project: Emilio Potenza 2010-2013
#
# Tools: generic AS
# libfindTools_LOG version: 0.1.0
# pysam version: 0.4.1
#
#################################################################################


__author__ = "Emilio Potenza"
__date__ = "$16-Aug-2011 11.42.28$"
__findTools__ = "libfindTools_AS"
__version__ = "0.1.0"


###############################################################################
# Imports
###############################################################################


import sys
from commands import getoutput
from getpass import getuser
from libfindTools_LOG import *
from math import fabs
from math import fmod
from numpy import max
import pysam
import operator


###############################################################################
# Definition and Decotrators
###############################################################################


def locusExploit():
    '''
    ### LOCUS CLUSTERING ###
    Clasterizzazione degli allineamenti per sovrapposizione.
    return: locusINcontig => dizionario per contig con lista Locus
    return: total => numero di contig presenti nell header del bam'
    '''
    locusINcontig = {}
    samfile = pysam.Samfile(input_bam, "rb")
    total = len(samfile.header["SQ"])
    print_log(locallog, "Inspecting Loci in %s contig."%(total))
    prog = ProgressBar(0, total, 90, mode='fixed', char='*')
    stop = 0
    c_id = 0
    for sq in samfile.header["SQ"]:
        '''stop+=1  #debug
        if stop>100:
            break'''
        contig=sq["SN"]
        ln=sq["LN"]
        locusINcontig[contig]=[]
        barPrint(prog, options.nohup)
        locus=''
        for AlgnRead in samfile.fetch(contig):
            if locus=='':
                c_id+=1
                locus=Locus(AlgnRead.pos, AlgnRead.aend, c_id)
                locus.upstat(AlgnRead)
            else:
                if AlgnRead.pos>locus.end:
                    c_id+=1
                    locusINcontig[contig].append(locus)
                    locus=Locus(AlgnRead.pos, AlgnRead.aend, c_id)
                    locus.upstat(AlgnRead)
                else:
                    locus.setEnd(AlgnRead.aend)
                    locus.upstat(AlgnRead)
        if locus!='':
            locusINcontig[contig].append(locus)
    samfile.close()
    print_input_param(locallog, "%s"%(getoutput("date")), "Clustering loci Done [")
    return locusINcontig, total


def locusStat(locusINcontig, total):
    '''
    ### Clustering Stat ###
    Statistiche di Clusterizzazione e di Loci
    return: locusINcontig => dizionario per contig con lista Locus
    return: sommaLoci => numero di Loci presenti nel bam'
    '''
    print_log(locallog, "Build statisctis in %s contig"%(total))
    prog = ProgressBar(0, 7, 90, mode='fixed', char='*')
    #loci
    loci=[]
    for contig in locusINcontig.keys():
        l=len(locusINcontig[contig])
        loci.append(l)
    sommaLoci=numpy.sum(loci)
    zeroLociContig=loci.count(0)
    moreLociContig=len(loci)-zeroLociContig
    mediaLoci=numpy.mean(loci)
    barPrint(prog, options.nohup)
    #moreloci=[]
    loci=[]
    for contig in locusINcontig.keys():
        l=len(locusINcontig[contig])
        if l>0:
            loci.append(l)
    mediaMoreLoci=numpy.mean(loci)
    stdMoreLoci=numpy.std(loci)
    barPrint(prog, options.nohup)
    #statQlen=[]
    loci=[]
    numReads=0
    numPaired=0
    for contig in locusINcontig.keys():
        for loco in locusINcontig[contig]:
            numReads+=loco.nReads
            numPaired+=loco.nPaired
            loci.extend(loco.qLen)
    sumQlen=numpy.sum(loci)
    barPrint(prog, options.nohup)
    #statRlen=[]
    loci=[]
    for contig in locusINcontig.keys():
        for loco in locusINcontig[contig]:
            loci.extend(loco.lenReads)
    avRlen=numpy.mean(loci)
    barPrint(prog, options.nohup)
    longReads=0
    for i in loci:
        if i> 300:
            longReads+=1
    barPrint(prog, options.nohup)
    #statNH
    loci=[]
    for contig in locusINcontig.keys():
        for loco in locusINcontig[contig]:
            loci.extend(loco.NH)
    singleReads=loci.count(1)
    multiReads=numReads-singleReads
    avNH=numpy.mean(loci)
    sumNH=numpy.sum(loci)
    barPrint(prog, options.nohup)
    #statNM
    loci=[] #statNM
    for contig in locusINcontig.keys():
        for loco in locusINcontig[contig]:
            loci.extend(loco.NM)
    avNM=numpy.mean(loci)
    barPrint(prog, options.nohup)
    ### End Print ###
    print_input_param(locallog, "%s"%(getoutput("date")), "Processed %s Loci   ["%(sommaLoci))
    print_result(locallog, "Map Properties", "null", 0)
    print_result(locallog, "Total n. Loci", sommaLoci, 1)
    print_result(locallog, "Total n. Reads", "%s (with %s paired)"%(numReads, numPaired), 1)
    print_result(locallog, "Total Map bp", sumQlen, 1)
    print_result(locallog, "Average Reads length", avRlen, 1)
    print_result(locallog, "Number of Long-Reads (>300bp)", longReads, 1)
    print_result(locallog, "Number of Single-Reads", singleReads, 1)
    print_result(locallog, "Number of Multi-Reads", "%s (with %s total hits)"%(multiReads, sumNH), 1)
    print_result(locallog, "Average n. of hits", avNH, 1)
    print_result(locallog, "Average n. of mismatch", avNM, 1)
    print_result(locallog, "Contig Properties", "null", 0)
    print_result(locallog, "Number of Contigs with 0 Locus", zeroLociContig, 1)
    print_result(locallog, "Average n. Loci", mediaLoci, 1)
    print_result(locallog, "Number of Contigs with 1+ Loci", moreLociContig, 1)
    print_result(locallog, "Average n. Loci", "%s std: %s "%(mediaMoreLoci, stdMoreLoci), 1)
    return locusINcontig, sommaLoci


def locusStatRAM(locusINcontig, total):
    '''
    ### Clustering Stat ###
    ### DEPRECATED ###
    Statistiche di Clusterizzazione e di Loci
    '''
    print_log(locallog, "Build statisctis in %s contig"%(total))
    prog = ProgressBar(0, total, 90, mode='fixed', char='*')
    loci=[]
    moreloci=[]
    statQlen=[]
    statRlen=[]
    statNH=[]
    statNM=[]
    numReads=0
    numPaired=0
    longReads=0
    for contig in locusINcontig.keys():
        barPrint(prog, options.nohup)
        l=len(locusINcontig[contig])
        loci.append(l)
        if l>0:
            moreloci.append(l)
        for loco in locusINcontig[contig]:
            numReads+=loco.nReads
            numPaired+=loco.nPaired
            statQlen.extend(loco.qLen)
            statNH.extend(loco.NH)
            statNM.extend(loco.NM)
            statRlen.extend(loco.lenReads)
    prog = ProgressBar(0, 14, 90, mode='fixed', char='*')
    sommaLoci = numpy.sum(loci)
    barPrint(prog, options.nohup)
    sumQlen = numpy.sum(statQlen)
    barPrint(prog, options.nohup)
    singleReads = statNH.count(1)
    barPrint(prog, options.nohup)
    multiReads = numReads-singleReads
    barPrint(prog, options.nohup)
    avNH = numpy.mean(statNH)
    barPrint(prog, options.nohup)
    sumNH = numpy.sum(statNH)
    barPrint(prog, options.nohup)
    avNM = numpy.mean(statNM)
    barPrint(prog, options.nohup)
    avRlen = numpy.mean(statRlen)
    barPrint(prog, options.nohup)
    for i in statRlen:
        if i > 300:
            longReads += 1
    barPrint(prog, options.nohup)
    zeroLociContig = loci.count(0)
    barPrint(prog, options.nohup)
    moreLociContig = len(loci)-zeroLociContig
    barPrint(prog, options.nohup)
    mediaLoci = numpy.mean(loci)
    barPrint(prog, options.nohup)
    mediaMoreLoci = numpy.mean(moreloci)
    barPrint(prog, options.nohup)
    stdMoreLoci = numpy.std(moreloci)
    barPrint(prog, options.nohup)
    ### End Print ###
    print_input_param(locallog, "%s"%(getoutput("date")), "Processed %s Loci   ["%(sommaLoci))
    print_result(locallog, "Map Properties", "null", 0)
    print_result(locallog, "Total n. Loci", sommaLoci, 1)
    print_result(locallog, "Total n. Reads", "%s (with %s paired)"%(numReads, numPaired), 1)
    print_result(locallog, "Total Map bp", sumQlen, 1)
    print_result(locallog, "Average Reads length", avRlen, 1)
    print_result(locallog, "Number of Long-Reads (>300bp)", longReads, 1)
    print_result(locallog, "Number of Single-Reads", singleReads, 1)
    print_result(locallog, "Number of Multi-Reads", "%s (with %s total hits)"%(multiReads, sumNH), 1)
    print_result(locallog, "Average n. of hits", avNH, 1)
    print_result(locallog, "Average n. of mismatch", avNM, 1)
    print_result(locallog, "Contig Properties", "null", 0)
    print_result(locallog, "Number of Contigs with 0 Locus", zeroLociContig, 1)
    print_result(locallog, "Average n. Loci", mediaLoci, 1)
    print_result(locallog, "Number of Contigs with 1+ Loci", moreLociContig, 1)
    print_result(locallog, "Average n. Loci", "%s std: %s "%(mediaMoreLoci, stdMoreLoci), 1)
    return locusINcontig, sommaLoci


def locusFilter(locusINcontig, total, sommaLoci, minRead, maxAvNH, maxAvNM):
    '''
    ### Locus Filtering ###
    Controllo Loci per numero di reads (minRead), media di hits (maxAvNH)
    e media di mismatch (maxAvNM)
    return locusINcontig => versione pulita dell'input
    return nFilterLoci => numero di Loci eliminati
    '''
    nh=0; nm=0; nr=0; multi=0;
    print_log(locallog, "Filtering %s loci"%(sommaLoci))
    prog = ProgressBar(0, total, 90, mode='fixed', char='*')
    nFilterLoci=0
    for contig in locusINcontig:
        barPrint(prog, options.nohup)
        for locus in locusINcontig[contig]:
            if numpy.mean(locus.NH)>maxAvNH:
                nhT=True
            else:
                nhT=False
            if numpy.mean(locus.NH)>maxAvNM:
                nmT=True
            else:
                nmT=False
            if locus.nReads<minRead:
                nrT=True
            else:
                nrT=False
            if nhT or nmT or nrT:
                ## Rimozione locus che non supera i filtri
                locusINcontig[contig].remove(locus)
                nFilterLoci+=1
            if [nhT, nmT, nrT].count(True)>1:
                multi+=1
            if nhT:
                nh+=1
            if nmT:
                nm+=1
            if nrT:
                nr+=1
    print_input_param(locallog, "%s"%(getoutput("date")), "Discarded %s Loci   ["%(nFilterLoci))
    print_result(locallog, "Filtering Properties", "null", 0)
    print_result(locallog, "Multi-Reads Trash", nh, 1)
    print_result(locallog, "Mismatch Trash", nm, 1)
    print_result(locallog, "n. Reads Trash", nr, 1)
    print_result(locallog, "multiple Trash", multi, 1)
    return locusINcontig, nFilterLoci


###############################################################################
# Classes
###############################################################################


class Locus():
    """
    Locus Classes, cluster of overlapping reads
    """

    def __init__(self, start, end, count):
        self.id = "LC%s"%(count)
        self.start = start
        self.end = end
        self.nReads = 0
        self.NH = []
        self.NM = []
        self.lenReads = []
        self.qLen = []
        self.nPaired = 0
        self.GP = []
        self.isChimera = False
        self.isNoGP = False
    
    def __str__(self):
        return "%s\t%s\t%s\t%s\t%s\t%s\t%s"%(self.id, self.start, self.end, self.nReads, self.isChimera, self.isNoGP, ",".join([x.id for x in self.GP]))

    def setStart(self, start):
        self.start = start

    def setEnd(self, end):
        if end > self.end:
            self.end = end

    def upReads(self):
        self.nReads += 1

    def randomStat(self):
        import random
        self.nReads = random.randint(1, 1000)
        self.nPaired=random.randint(0, self.nReads)
        self.lenReads.extend([random.randint(75, 600) for j in range(self.nReads)])
        self.qLen=self.lenReads[:]
        self.NH.extend([random.randint(0, 40) for j in range(self.nReads)])
        self.NM.extend([random.randint(0, 20) for j in range(self.nReads)])

    def tmp(self):
        return self.id

    def upstat(self, read):
        self.upReads()
        if read.is_paired:
            self.nPaired+=1
        try:
            self.NM.append(int(read.opt("NM")))
        except:
            self.NM.append(0)
        try:
            self.NH.append(int(read.opt("NH")))
        except:
            self.NH.append(0)
        rlen=read.rlen
        if rlen==0: #if info is unavailable
            rlen=read.qlen
        self.lenReads.append(rlen)
        self.qLen.append(read.qlen)


class Cluster():

    def __init__(self, id, clst, contig, x_contig, min_intron, min_donacc, site_tolerance, max_path, max_stop, debug_tf):
        self.debug=debug_tf
        ##Parametri minima dimensione introne e donor Acceptor
        self.min_intron=min_intron
        self.min_donacc=min_donacc
        self.site_tolerance=site_tolerance #deve essere minore delle due precedenti
        self.min_illumina=50 #se la reads e' piu' corta, uso solo le reads con splice site
        ##T/F AS nel Cluster
        self.AS=False
        ##Conto Blocchi True
        self.count_AS_b=0
        ##Contig ID
        self.contig=contig
        self.x_contig=x_contig
        ##Cluster ID
        self.id=id
        ##Lista di reads in sam Format
        self.clst=clst
        ##print clst[0].cigar
        #self.paths = []
        self.pesi={} #pesi degli archi
        self.max_path=max_path
        self.stop=0
        self.max_stop=max_stop

    def run(self, LOG): #,STAT):
        self.print_debug=[]  #da rimuovere perche' si deve sostituire con LOG Verbose
        #LOG
        self.LOG=LOG
        #self.STAT=STAT
        self.LOG.WriteLog('DEV', 'Cluster ID = %s'%(self.id))
        self.LOG.WriteLog('DEV', 'Cluster Contig = %s'%(self.contig))
        ##LOG and STAT object
        self.LOG=LOG
        #self.STAT=STAT
        ##Converte la lista di reads da SAM a Read()
        self.reads = self.samConvert(self.clst)
        self.freqStart, self.freqEnd = self.doSiteFreq()
        ##Annullo Cluster
        del self.clst
        if len(self.reads)>0: #se ho reads buone
            ##Set start/end del cluster
            self.start, self.end = self.minMax()

            #self.sSites,self.eSites=self.bindingReads_altd()

            ##Calcola la distribuzione,
            self.dist, self.blocks = self.buildDistribution()
            ##Calcola T/F per ogni tipo di AS in ogni blocco [(IR,ES,AD,AA),(...)..for each block
            self.prediction = self.findAS()
            ##Annullo Cluster
            del self.dist
            ##Conteggi AS per blocco e setto AS T/F
            self.count_AS_b, self.AS = self.findASresult()

            #self.sSites,self.eSites=self.bindingReads()
            self.sSites, self.eSites=self.bindingReads_altd()

            ##Calcola i trascritti; grafo ed dfs
            self.paths = self.findASpaths()

            ##LOG
            self.LOG.WriteLog('DEV', 'Number of Reads Clst %s => %s : %s'%(self.id, self.contig, len(self.reads)))
            self.LOG.WriteLog('DEV', 'Position Clst %s => %s : %s - %s'%(self.id,self.contig,self.start,self.end))
            self.LOG.WriteLog('DEV', 'Blocks Clst %s => %s : %s'%(self.id,self.contig,self.blocks))
            self.LOG.WriteLog('DEV', 'Prediction Clst %s => %s : %s'%(self.id,self.contig,self.prediction))
            self.LOG.WriteLog('DEV', 'findAS Clst %s => %s : %s - %s'%(self.id,self.contig,self.AS,self.count_AS_b))
            self.LOG.WriteLog('DEV', 'Number of Paths Clst %s => %s : %s'%(self.id,self.contig,len(self.paths)))
            self.LOG.WriteLog('INF', 'Cluster %s, %s, %s-%s, num.Reads %s, AS %s'%(self.id,self.contig,self.start,self.end,len(self.reads),self.AS))
            ##Statistics
            #...
            ##Killati
            #del self
        else:
            self.paths=[]
            self.LOG.WriteLog('INF','Cluster ID = %s STOPPED no good reads'%(self.id))
            #del self
        return

    def doSiteFreq(self):
        S={}
        E={}
        for read in self.reads:
            for s in read.startSites:
                try:
                    S[s]+=1
                except:
                    S[s]=1
            for e in read.endSites:
                try:
                    E[e]+=1
                except:
                    E[e]=1
        return S, E

    def getFreqS_E(self,diz,x):
        #x = {1: 2, 3: 4, 4:3, 2:1, 0:0}
        #sorted_x = sorted(x.iteritems(), key=operator.itemgetter(1))
        list_site=[]
        for y in diz.keys():
            if fabs(x-y)<=self.min_donacc:
                list_site.append((y,diz[y]))
        sorted(list_site, key=operator.itemgetter(1))
        if list_site!=[]:
            return list_site[0][0]
        return x

    def getExtend(self, site,s_e):

        def compare_freqStart(x, y):
            dif=self.freqStart[x]-self.freqStart[y]
            if dif>0:
                return -1
            elif dif<0:
                return 1
            else:
                return 0

        def compare_freqEnd(x, y):
            dif=self.freqEnd[x]-self.freqEnd[y]
            if dif>0:
                return -1
            elif dif<0:
                return 1
            else:
                return 0

        list_site=[]
        block=self.getblock(site)
        if s_e=="start":
            for s in self.freqStart.keys():
                if s>=block[0] and s<=block[1]:
                    if fabs(site-s)<=self.min_donacc:
                        list_site.append(s)
            list_site=sorted(list_site, cmp=compare_freqStart)
        elif s_e=="end":
            for e in self.freqEnd.keys():
                if e>=block[0] and e<=block[1]:
                    if fabs(site-e)<=self.min_donacc:
                        list_site.append(e)
            list_site=sorted(list_site, cmp=compare_freqEnd)
        if list_site!=[]:
            return list_site[0]
        return site

    def getblock(self,x):
        for block in self.blocks:
            if x>=block[0] and x<=block[1]:
                return block

    def bindingReads_altd(self):
        sSites=[]
        eSites=[]
        for read in self.reads:
            sSites.extend(read.startSites)
            eSites.extend(read.endSites)
        sSites.append(self.start)
        eSites.append(self.end)
        for block in self.blocks:
            sSites.append(block[0])
            eSites.append(block[1])
        sSites=list(set(sSites))
        sSites.sort()
        eSites=list(set(eSites))
        eSites.sort()
        self.LOG.WriteLog('DEV','Start Splice Site %s = %s : %s'%(self.id,self.contig,sSites))
        self.LOG.WriteLog('DEV','End Splice Site %s = %s : %s'%(self.id,self.contig,eSites))
        #print 'DEV','Start Splice Site %s = %s : %s'%(self.id,self.contig,sSites)
        #print 'DEV','End Splice Site %s = %s : %s'%(self.id,self.contig,eSites)
        for read in self.reads:
            self.LOG.WriteLog('DEV','real Reads %s = %s : %s'%(read.qname,self.contig,read.realexons))
            #print 'DEV','real Reads %s = %s : %s'%(read.qname,self.contig,read.realexons)
            for i,exon in enumerate(read.exons):
                #Extend EndSite
                xxEnd=exon[1]
                for j in range(len(eSites)):
                    if xxEnd>eSites[j]:
                        pass
                    elif xxEnd==eSites[j]:
                        break
                    else:
                        xxEnd=eSites[j]
                        break
                #exon[1]=xxEnd
                xxStart=exon[0]
                for j in range(len(sSites)):
                    if xxStart>sSites[j]:
                        pass
                    elif xxStart==sSites[j]:
                        break
                    else:
                        xxStart=sSites[j-1]
                        break
                #exon[0]=xxStart
                xxStart=self.getExtend(xxStart,"start")
                xxEnd=self.getExtend(xxEnd,"end")
                if xxEnd-xxStart > 1:
                    read.exons[i]=(xxStart,xxEnd)
            #print 'DEV','extended Reads %s = %s : %s'%(read.qname,self.contig,read.exons)
            self.LOG.WriteLog('DEV','extended Reads %s = %s : %s'%(read.qname,self.contig,read.exons))
        return sSites,eSites

    def bindingReads(self):
        sSites=[]
        eSites=[]
        for read in self.reads:
            sSites.extend(read.startSites)
            eSites.extend(read.endSites)
        sSites.append(self.start)
        eSites.append(self.end)
        for block in self.blocks:
            sSites.append(block[0])
            eSites.append(block[1])
        sSites=list(set(sSites))
        sSites.sort()
        eSites=list(set(eSites))
        eSites.sort()
        self.LOG.WriteLog('DEV','Start Splice Site %s = %s : %s'%(self.id,self.contig,sSites))
        self.LOG.WriteLog('DEV','End Splice Site %s = %s : %s'%(self.id,self.contig,eSites))
        #print 'DEV','Start Splice Site %s = %s : %s'%(self.id,self.contig,sSites)
        #print 'DEV','End Splice Site %s = %s : %s'%(self.id,self.contig,eSites)
        for read in self.reads:
            self.LOG.WriteLog('DEV','real Reads %s = %s : %s'%(read.qname,self.contig,read.realexons))
            #print 'DEV','real Reads %s = %s : %s'%(read.qname,self.contig,read.realexons)
            for i,exon in enumerate(read.exons):
                #Extend EndSite
                xxEnd=exon[1]
                for j in range(len(eSites)):
                    if xxEnd>eSites[j]:
                        pass
                    elif xxEnd==eSites[j]:
                        break
                    else:
                        xxEnd=eSites[j]
                        break
                #exon[1]=xxEnd
                xxStart=exon[0]
                for j in range(len(sSites)):
                    if xxStart>sSites[j]:
                        pass
                    elif xxStart==sSites[j]:
                        break
                    else:
                        xxStart=sSites[j-1]
                        break
                #exon[0]=xxStart
                read.exons[i]=(xxStart,xxEnd)
            #print 'DEV','extended Reads %s = %s : %s'%(read.qname,self.contig,read.exons)
            self.LOG.WriteLog('DEV','extended Reads %s = %s : %s'%(read.qname,self.contig,read.exons))
        return sSites,eSites

    def findASpaths(self):

        def find_all_paths(graph, start, end, path=[]):
            ##find all possible path from each 'root' to each 'leaf'
            ##where 'root' is a node in the graph with edge to all real root
            ##and 'leaf' is a node in the graph without any outside edge but all real leaf have an edge to 'leaf'
            if start not in ['root','leaf']:
                path = path + [start]
            if start == end:
                return [path]
            if not graph.has_key(start): #if not in graph: #if not graph.has_key(start): #deprecated
                return []

            paths = []
            #print len(paths)
            self.stop+=1
            if self.stop==self.max_stop:
                print_error(self.LOG,'Stop Iteration in Cluster %s, %s, %s-%s, num.Reads %s, AS %s => Set recursion limit; => Return First Path'%(self.id,self.contig,self.start,self.end,len(self.reads),self.AS))
                self.LOG.WriteLog('ERR','Stop Iteration in Cluster %s, %s, %s-%s, num.Reads %s, AS %s => Set recursion limit; => Return First Path'%(self.id,self.contig,self.start,self.end,len(self.reads),self.AS))
                return paths #[]

            for node in graph[start]:
                if node not in path and node!=start:
                    newpaths = find_all_paths(graph, node, end, path)
                    for newpath in newpaths:
                        append_to_paths(paths, newpath)
                else:
                    print_error(self.LOG,'Graph Error, node not in path %s, %s, %s-%s, num.Reads %s, AS %s => Return None'%(self.id,self.contig,self.start,self.end,len(self.reads),self.AS))
                    self.LOG.WriteLog('ERR','Graph Error, node not in path %s, %s, %s-%s, num.Reads %s, AS %s => Return None'%(self.id,self.contig,self.start,self.end,len(self.reads),self.AS))
                    return []
            return paths

        def compare(path, path_1):
            dif=path_score(path)-path_score(path_1)
            if dif>0:
                return -1
            elif dif<0:
                return 1
            else:
                return 0

        def path_score(path):
            #Somma pesi introni
            score=0.
            for i in range(len(path)-1):
                try:
                    score+=self.pesi[(path[i],path[i+1])]
                except:
                    pass
            return score

        def expandSingle(paths):
            #import time
            #print 'paths',len(paths)
            for p,path in enumerate(paths):
                #per ogni esone singlo trovo se posso estendere gli estremi
                e_path=[]
                s_path=[]
                if len(path)==1:
                    s=path[0][0]
                    e=path[0][1]
                    for subpath in paths:
                        if len(subpath)>1:
                            for n,exon in enumerate(subpath):
                                if exon!=path[0]:
                                    if s==exon[0]:
                                        if subpath[:n] not in s_path:
                                            s_path.append(subpath[:n])
                                    if e==exon[1]:
                                        try:
                                            if subpath[n+1:] not in e_path:
                                                e_path.append(subpath[n+1:])
                                        except:
                                            pass
                                else:
                                    pass
                    #lista degli estremi da attaccare al path singolo
                    if s_path!=[] and e_path!=[]:
                        #paths.pop(p)
                        for s_p in s_path:
                            for e_p in e_path:
                                #print s_p,'+',path,'+',e_p
                                if len(paths)>0:
                                    paths=append_to_paths_return(paths,s_p+path+e_p)
                                else:
                                    paths.append(s_p+path+e_)
                    elif s_path==[] and e_path!=[]:
                        #paths.pop(p)
                        for e_p in e_path:
                            #print path,'+',e_p
                            if len(paths)>0:
                                paths=append_to_paths_return(paths,path+e_p)
                            else:
                                paths.append(path+e_p)

                    elif s_path!=[] and e_path==[]:
                        #paths.pop(p)
                        for s_p in s_path:
                            #print s_p,'+',path
                            if len(paths)>0:
                                paths=append_to_paths_return(paths,s_p+path)
                            else:
                                paths.append(s_p+path)
                    else:
                        pass
            #time.sleep(0.5)
            return paths

        def cleanSingleInMulty(paths):
            n_remove=[]
            MultiCheck=False
            for n,path in enumerate(paths):
                if len(path)>1:
                    MultiCheck=True
                elif len(path)==1:
                    n_remove.append(n)
                else:
                    pass
            if MultiCheck:
                poppi=0
                for r in n_remove:
                    paths.pop(r-poppi)
                    poppi+=1
            return paths

        def adaptBorder(paths):
            p_list=[]
            for p,path in enumerate(paths):
                s=path[0][0]
                e=path[-1][1]
                s_p=list(path[0])
                s_p[0]=self.getFreqS_E(self.freqStart,s)
                path[0]=tuple(s_p)
                e_p=list(path[-1])
                e_p[1]=self.getFreqS_E(self.freqEnd,e)
                path[-1]=tuple(e_p)
                check_small_exon=False
                for exon in path:
                    if exon[-1]-exon[0]<2:
                        check_small_exon=True
                if not check_small_exon:
                    p_list.append(tuple(path))
            p_list=list(set(p_list))
            p_list=[list(x) for x in p_list]
            return p_list

        def expandMulty(paths,start,end):
            #import time
            #print 'paths',len(paths)
            for p,path in enumerate(paths):
                #per ogni esone singlo trovo se posso estendere gli estremi
                e_path=[]
                s_path=[]
                if len(path)>1:
                    s=path[0][0]
                    e=path[-1][1]
                    for subpath in paths:
                        if len(subpath)>1 and subpath!=path:
                            for n,exon in enumerate(subpath):
                                if s==exon[0] and s!=start:
                                    if subpath[:n] not in s_path:
                                        s_path.append(subpath[:n])
                                if e==exon[1] and e!=end:
                                    try:
                                        if subpath[n+1:] not in e_path:
                                            e_path.append(subpath[n+1:])
                                    except:
                                        pass
                                else:
                                    pass
                    #lista degli estremi da attaccare al path singolo
                    if s_path!=[] and e_path!=[]:
                        #paths.pop(p)
                        for s_p in s_path:
                            for e_p in e_path:
                                #print s_p,'+',path,'+',e_p
                                if len(paths)>0:
                                    paths=append_to_paths_return(paths,s_p+path+e_p)
                                else:
                                    paths.append(s_p+path+e_)
                    elif s_path==[] and e_path!=[]:
                        #paths.pop(p)
                        for e_p in e_path:
                            #print path,'+',e_p
                            if len(paths)>0:
                                paths=append_to_paths_return(paths,path+e_p)
                            else:
                                paths.append(path+e_p)

                    elif s_path!=[] and e_path==[]:
                        #paths.pop(p)
                        for s_p in s_path:
                            #print s_p,'+',path
                            if len(paths)>0:
                                paths=append_to_paths_return(paths,s_p+path)
                            else:
                                paths.append(s_p+path)
                    else:
                        pass
            #time.sleep(0.5)
            return paths

        def append_to_paths_return(paths,path):
            if len(path)>0:
                peso=path_score(path)
                if len(paths)<self.max_path:
                    paths.append(path)
                else:
                    p_list=[tuple(x) for x in paths]
                    p_list=list(set(p_list))
                    paths=[list(x) for x in p_list]
                    if len(paths)>=self.max_path:
                        paths=sorted(paths, cmp=compare)
                        if peso>path_score(paths[-1]):
                            paths[-1]=path
                        elif peso==path_score(paths[-1]):
                            paths.append(path)
                            paths=sorted(paths, cmp=compare)
                            if len(paths)>self.max_path:
                                paths=paths[:self.max_path]
                        else:
                            pass
                    else:
                        pass
            return paths

        def append_to_paths(paths,path):

            def removeSingleInMulti(paths):
                #se esiste un percorso con piu' di uno splice site---tolgo i percorsi a singoli esoni
                if len(paths)>1:
                    n_remove=[]
                    MultiCheck=False
                    for n,path in enumerate(paths):
                        if len(path)>1:
                            MultiCheck=True
                        elif len(path)==1:
                            n_remove.append(n)
                        else:
                            pass
                    if MultiCheck:
                        poppi=0
                        for r in n_remove:
                            paths.pop(r-poppi)
                            poppi+=1
                return paths

            #calc peso
            if len(path)>0:
                peso=path_score(path)
                if len(paths)<self.max_path:
                    paths.append(path)
                else:
                    #paths=expandSingle(paths)
                    paths=sorted(paths, cmp=compare)
                    if peso>path_score(paths[-1]):
                        paths[-1]=path
                    elif peso==path_score(paths[-1]):
                        paths.append(path)
                        paths=sorted(paths, cmp=compare)
                        if len(paths)>self.max_path:
                            paths=paths[:self.max_path]
                    else:
                        pass
            #paths=expandSingle(paths)
            #paths=removeSingleInMulti(paths)
            return

        def buildgraph(site_tolerance):

            def exon_in_hash(exon,site_tolerance,master_exon):
                #return true if exon is alrerady in master dictionary
                for node in master_exon.keys():
                    #print exon,node
                    if fabs(exon[0]-node[0]) <= site_tolerance and fabs(exon[1]-node[1]) <= site_tolerance:
                        return node
                return "None"

            def rebuilt_master(master_exon,master,last):
                ##setta come master il piu' rappresentativo o l'ultimo
                lista=master_exon[master]
                if len(lista)>1:
                    del master_exon[master]
                    hash={}
                    for exon in lista:
                        hash[exon]=0
                    for exon in lista:
                        hash[exon]+=1
                    m=max(hash.values())
                    best_list=[]
                    for best in hash.keys():
                        if hash[best]==m:
                            best_list.append(best)
                    if len(best_list)==len(lista):
                        master_exon[last]=lista
                    elif len(best_list)==1:
                        master_exon[best_list[0]]=lista
                    else:
                        master_exon[best_list[-1]]=lista
                else:
                    pass
                return master_exon

            def block_is_AS(index):
                ##se il blocco ha un AS, passando l'indice; non ES
                for AS in self.prediction[index][:1]+self.prediction[index][2:]:
                    if AS:
                        return True
                return False

            ##Creo lista esoni per blocco
            blocks_exon=[] #[[list_block1],...]
            for block in self.blocks:
                    b_start=block[0]
                    b_end=block[1]
                    b_exon=[] #lista esoni per blocco
                    for read in self.reads:
                        for exon in read.exons:
                            if exon[0]>=b_start and exon[1]<=b_end:
                                if exon not in b_exon:
                                    b_exon.append(exon)
                            elif exon[0]>b_end:
                                break
                            else:
                                pass
                    blocks_exon.append(b_exon)

            ##identifico esoni caratteristici
            ##esoni in ordine; sposto la finestra di basi=tolleranza;
            ##se trovo un esone lo aggingo alla lista del master corrispondente;
            ##modifico il master con l'esone piu' presente o con l'ultimo in caso ti tutti uguali

            ##Creo un hash master_esone:lista esoni
            master_exon={}
            for n,block in enumerate(self.blocks):
                if block_is_AS(n):
                    #print block, blocks_exon
                    block_master_exon={}
                    for exon in blocks_exon[n]:
                        node=exon_in_hash(exon, site_tolerance, block_master_exon)
                        if node!='None':
                            block_master_exon[node].append(exon)
                            block_master_exon = rebuilt_master(block_master_exon,node,exon)
                        else:
                            block_master_exon[exon]=[exon]
                    master_exon.update(block_master_exon)
                else:
                    #se non ch'e' AS, prendo lo start piu' freq e piu' esterno: end piu' freq e piu' esterno
                    hashS={}
                    hashE={}
                    for read in self.reads:
                        for s in read.startSites:
                            if s>=block[0] and s<=block[1]:
                                try:
                                    hashS[s]+=1
                                except:
                                    hashS[s]=1
                    for read in self.reads:
                        for e in read.endSites:
                            if e>=block[0] and e<=block[1]:
                                try:
                                    hashE[e]+=1
                                except:
                                    hashE[e]=1
                    self.LOG.WriteLog("DEV","HashE: %s"%(hashE))
                    self.LOG.WriteLog("DEV","HashS: %s"%(hashS))
                    try:
                        mS=max(hashS.values())
                        best_listS=[]
                        for bestS in hashS.keys():
                            if hashS[bestS]==mS:
                                best_listS.append(bestS)
                        best_listS.sort()
                        self.LOG.WriteLog("DEV","best_listS: %s"%(best_listS))
                        masterS=best_listS[0]
                    except:
                        masterS=block[0]
                        self.LOG.WriteLog("DEV","except best_listS: %s"%(block[0]))
                    try:
                        mE=max(hashE.values())
                        best_listE=[]
                        for bestE in hashE.keys():
                            if hashE[bestE]==mE:
                                best_listE.append(bestE)
                        best_listE.sort()
                        self.LOG.WriteLog("DEV","best_listE: %s"%(best_listE))
                        masterE=best_listE[-1]
                    except:
                        masterE=block[1]
                        self.LOG.WriteLog("DEV","except best_listE: %s"%(block[1]))
                    if masterS>=masterE:
                        master_exon[block]=blocks_exon[n] #per incongruita in start, end sovrapposte
                    else:
                        if (masterS,masterE)!=block:
                            master_exon[(masterS,masterE)]=blocks_exon[n]
                            master_exon[block]=blocks_exon[n]
                        else:
                            master_exon[block]=blocks_exon[n]
                    self.LOG.WriteLog("DEV","best exon: %s"%([masterS,masterE]))
                    #master_exon[block]=blocks_exon[n]

            ##Creo un hash binario esone:master_esone
            exon2master={}
            for exon in master_exon.keys():
                for subexon in master_exon[exon]:
                    exon2master[subexon]=exon

            ##Creo il grafo
            graph={}
            for exon in master_exon:
                graph[exon]=[]
            for read in self.reads:

                ##NONsalto gli esoni singoli
                if len(read.exons)>1:
                    ##setto gli archi, passo dagli esoni ai master
                    for ex in range(len(read.exons)-1):
                        try:
                            graph[exon2master[read.exons[ex]]].append(exon2master[read.exons[ex+1]])

                            try:
                                self.pesi[(exon2master[read.exons[ex]],exon2master[read.exons[ex+1]])]+=1
                            except:
                                self.pesi[(exon2master[read.exons[ex]],exon2master[read.exons[ex+1]])]=1
                        except Exception, e:
                            print Exception, e, read.qname,read.rname, read.exons, read.exons[ex],read.exons[ex+1]
                            print_error(self.LOG,e)
                else:
                    pass #ex=read.exons[0]

            ##elimino eventuali nodi rimasti vuoti, cioe' elimino le reads a singolo esone
            for node in graph.keys():
                if graph[node]==[]:
                    pass
                else:
                    ##Elimino il problema degli intronni troppo piccoli che non vengono riconosciuti come IR e creano
                    ##nodi con arco su se stesso ed elimino le ripetizioni
                    try:
                        graph[node]=list(set(graph[node])) #archi circolari
                        graph[node].remove(node) #ripetizioni
                    except:
                        pass
            self.LOG.WriteLog("DEV","Master Exon: %s"%(master_exon))
            return graph

        ##main###
        ##a sample graph
        '''graph = {'A': ['B'],B': ['C', 'D'],'C': ['D']}'''
        graph=buildgraph(self.site_tolerance)
        self.LOG.WriteLog("DEV","Graph: %s"%(graph))
        ##List of graph keys and value
        keys=graph.keys()
        values=[]
        for edges in graph.values():
            for edge in edges:
                values.append(edge)
        ##Identify root and leaf in the graph
        root=[]
        leaf=[]
        for node in keys:
            if node not in values:
                if node not in root:
                    root.append(node)
        for node in keys:
            if graph[node]==[]:
                leaf.append(node)
        self.LOG.WriteLog("DEV","Graph Roots: %s"%(root))
        self.LOG.WriteLog("DEV","Graph Leafs: %s"%(leaf))
        ##Add root and leaf tag in the graph for find_all_path
        graph['root']=root
        for i in leaf:
            graph[i]=['leaf']
        self.LOG.WriteLog("DEV","Graph Leafs and Roots: %s"%(graph))

        if len(root)==0 or len(leaf)==0:
            print_error(self.LOG,"No Root or No Leaf")
            self.LOG.WriteLog("ERR","No Root or No Leaf")
            #Exit?

        ##find paths
        if True:
            #try:
            #
            paths=find_all_paths(graph, 'root', 'leaf')
            paths=adaptBorder(paths)
            paths=expandSingle(paths)
            paths=cleanSingleInMulty(paths)
            paths=expandMulty(paths, self.start, self.end)
            paths=adaptBorder(paths)
            #
            #except:
            #
            #paths=[]
            #print_error(self.LOG,"%s Find All Paths Error -> skip"%(self.id))
            #self.LOG.WriteLog("ERR","%s Find All Paths Error -> skip"%(self.id))
        return paths

    def getdebug(self):
        self.print_debug.append(self.outputSAMformat())
        return self.print_debug

    def outputSAMformat(self):
        sam=[]
        #Flag da modificare--->16
        if self.paths!=None:
            for n,path in enumerate(self.paths):
                ##Ricostruisco il cigar
                cigar=""
                for ex in range(len(path)-1):
                    if path[ex][1]-path[ex][0]<0:
                        print_error(self.LOG,"%s %s path=%s ex=%s [path[ex][1]-path[ex][0] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex][1],path[ex][0]))
                        self.LOG.WriteLog("ERR","%s %s path=%s ex=%s [path[ex][1]-path[ex][0] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex][1],path[ex][0]))
                        #for read in self.reads:
                        #    print read.qname,read.exons
                        return []
                    cigar=cigar+"%sM"%(path[ex][1]-path[ex][0]+1)
                    if path[ex+1][0]-path[ex][1]<0:
                        print_error(self.LOG,"%s %s path=%s ex=%s [path[ex+1][0]-path[ex][1] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex+1][0],path[ex][1]))
                        self.LOG.WriteLog("ERR","%s %s path=%s ex=%s [path[ex+1][0]-path[ex][1] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex+1][0],path[ex][1]))
                        #for read in self.reads:
                        #    print read.qname,read.exons
                        return []
                    cigar=cigar+"%sD"%(path[ex+1][0]-path[ex][1]-1)
                cigar=cigar+"%sM"%(path[-1][1]-path[-1][0]+1)
                ##ID isoforma
                path_id="Clst%s_Iso%s"%(self.id,n)
                ##Start
                start=path[0][0]
                str="%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s"%(path_id,"16",self.contig,start,"255",cigar,"*","0","0","*","*")
                sam.append(str)
        else:
            print_error(self.LOG,"%s No Path -> skip"%(self.id))
            self.LOG.WriteLog("ERR","%s No Path -> skip"%(self.id))
        return sam

    def outputBAMformat(self):
        bams=[]
        #Flag da modificare--->16
        if self.paths!=None:
            for n,path in enumerate(self.paths):
                ##Ricostruisco il cigar
                cigar=[]
                for ex in range(len(path)-1):
                    if path[ex][1]-path[ex][0]<0:
                        print_error(self.LOG,"%s %s path=%s ex=%s [path[ex][1]-path[ex][0] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex][1],path[ex][0]))
                        self.LOG.WriteLog("ERR","%s %s path=%s ex=%s [path[ex][1]-path[ex][0] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex][1],path[ex][0]))
                        #for read in self.reads:
                        #    print read.qname,read.exons
                        return []
                    cigar.append((0,path[ex][1]-path[ex][0]+1)) #=cigar+"%sM"%(path[ex][1]-path[ex][0]+1)
                    if path[ex+1][0]-path[ex][1]<0:
                        print_error(self.LOG,"%s %s path=%s ex=%s [path[ex+1][0]-path[ex][1] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex+1][0],path[ex][1]))
                        self.LOG.WriteLog("ERR","%s %s path=%s ex=%s [path[ex+1][0]-path[ex][1] %s-%s] -> skip"%(self.id,self.contig,path,ex,path[ex+1][0],path[ex][1]))
                        #for read in self.reads:
                        #    print read.qname,read.exons
                        return []
                    cigar.append((2,path[ex+1][0]-path[ex][1]-1)) #cigar+"%sD"%(path[ex+1][0]-path[ex][1]-1)
                cigar.append((0,path[-1][1]-path[-1][0]+1)) #=cigar+"%sM"%(path[-1][1]-path[-1][0]+1)
                ##ID isoforma
                path_id="Clst%s_Iso%s"%(self.id,n)
                ##Start
                start=path[0][0]
                #str="%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s"%(path_id,"16",self.contig,start,"255",cigar,"*","0","0","*","*")
                a = pysam.AlignedRead()
                a.qname = path_id
                a.seq=""
                a.qual=""
                a.flag = 16
                a.rname = self.x_contig
                a.pos = start
                a.mapq = 255
                a.cigar =tuple(cigar) # ( (0,10), (2,1), (0,25) )
                #a.qual="<<<<<<<<<<<<<<<<<<<<<:<9/,&,22;;<<<"
                #a.tags = ( ("NM", 1),("RG", "L1") )
                bams.append(a)
        else:
            print_error(self.LOG,"%s No Path -> skip"%(self.id))
            self.LOG.WriteLog("ERR","%s No Path -> skip"%(self.id))
        return bams

    def findASresult(self):
        ##Conto Blocchi True
        count_AS_b=0
        AS_TF=False
        for i in self.prediction:
            for j in i:
                if j:
                    AS_TF=True
                    count_AS_b+=1
                    break
        return count_AS_b, AS_TF

    def findAS(self):
        prediction=[]   #[(IR,ES,AD,AA),()..for each block
        for b in self.blocks:
            b_start=b[0]
            b_end=b[1]
            difPos = False
            difNeg = False
            IR=False
            ES=True
            AD=False
            AA=False
            xy=[0.,0,0]
            try:
                for bp in range(b_start-self.start,b_end-self.start):
                    #print b_start,b_end,len(self.dist),bp
                    d = self.dist[bp]
                    d_next = self.dist[bp+1]
                    ###IR###
                    if (difPos==False and d - d_next > 0):
                        difPos=True
                        check=bp
                    if (difPos and bp-check > self.min_intron):
                        if d - d_next < 0:
                            difNeg=True
                    if difPos and difNeg:
                        IR=True
                    ###ES###
                    if ES==True and d==100:
                        ES=False
                    ###AD###01
                    if True: #self.blocks.index(b)!=0 and self.blocks.index(b)!= len(self.blocks)-1: #se non e' il primo o l'ultimo blocco
                        if d>xy[0]:
                            xy=[d,bp,bp]
                        elif d==xy[0]:
                            xy[2]=bp
                        else:
                            pass
                    ###break###
                    if d==0:
                        print_error(self.LOG,"BUG: Distribution Zero %s %s %s %s"%(b_start,b_end,len(self.dist),bp))
                        self.LOG.WriteLog("ERR","BUG: Distribution Zero %s %s %s %s"%(b_start,b_end,len(self.dist),bp))
                    if IR and ES and AD:
                        print_error(self.LOG,"DEBUG: break findAS %s %s %s %s"%(b_start,b_end,len(self.dist),bp))
                        self.LOG.WriteLog("ERR","DEBUG: break findAS %s %s %s %s"%(b_start,b_end,len(self.dist),bp))
                        break
                ###AD###02
                #print xy,b_start-self.start,b_end-self.start
                if xy[0]>self.dist[b_start-self.start] and xy[1]-(b_start-self.start)>self.min_donacc:
                    AD=True
                if xy[0]>self.dist[b_end-self.start] and (b_end-self.start)-xy[2]>self.min_donacc:
                    AA=True
                prediction.append((IR,ES,AD,AA))
            except:
                print_error(self.LOG,"findAS Prediction Error")
                self.LOG.WriteLog("ERR","findAS Prediction Error")
                EXIT(0)
        return prediction

    def minMax(self):
        #Le reads devono essere in ordine; sort bam as input
        s=self.reads[0].start
        e=self.reads[0].end
        for r in self.reads:
            #print r.exons
            if r.end>e:
                e=r.end
        #print s,e
        return s,e

    def buildDistribution(self):
        dist=[]
        block_start=0
        block_end=0
        blocks=[]
        for bp in range(self.start,self.end+1):
            #dist.append(0)
            Ex_Cov=0.
            Re_Cov=0.
            #compute XX coverage distribution on bp
            for r in self.reads:
                for e in r.exons:
                    if bp >= e[0] and bp <= e[1]: #exon coverage
                        #ex_dist[-1]+=1
                        Ex_Cov+=1
                        break
                    else:
                        pass
                if bp>=r.start and bp<= r.end:
                    Re_Cov+=1
                elif bp<r.start:
                    break
                else:
                    pass
            if Ex_Cov==0:
                dist.append(0.)
            else:
                dist.append(Ex_Cov/Re_Cov*100)
            #blocks start end
            if dist[-1]==0:#XX==0:#
                if block_start!=0 and block_end!=0:
                    blocks.append((block_start,block_end))
                    block_start=0
                    block_end=0
                else:
                    pass
            else:
                if block_start!=0 and block_end!=0:
                    block_end=bp
                else:
                    block_start=bp
                    block_end=bp
        blocks.append((block_start,block_end))
        return dist, blocks

    def samConvert(self,clst):
        reads=[]
        for read in clst:
            tmp=Read(self.id, read.qname, read.pos, read.rlen, read.cigar, read.is_reverse, read.rname, read.mapq,self.min_intron,self.LOG)  # read.opt("AS")
            '''if tmp.rlen>self.min_illumina:
                reads.append(tmp)  # read.opt("AS")
            else:
                if len(tmp.exons)>1:
                    reads.append(tmp)'''
            reads.append(tmp)
        return reads


class Read():

    def __init__(self, cluster_id, qname, pos, rlen, cigar, reverse, rname, mapq,minIR,LOG):
        ## in convertCigar
        merge=minIR-1
        self.LOG=LOG
        self.cluster_id = cluster_id
        self.qname = qname #sequence id
        self.start = pos +1 #start pos on contig
        self.rlen = rlen
        self.reverse = reverse
        self.rname = rname
        self.mapq = mapq
        self.exons, self.end = self.convertCigar(cigar,merge)
        self.realexons = self.exons[:]
        self.mergeExon(merge)
        self.startSites,self.endSites=self.spliceSites()
        self.LOG.WriteLog("DEV","Read = %s Cigar = %s Exons = %s"%(self.qname,cigar,self.exons))
        self.LOG.WriteLog("DEV","Read = %s startSites = %s endSites = %s"%(self.qname,self.startSites,self.endSites))

    def spliceSites(self):
        startSites=[]
        endSites=[]
        for exon in self.exons:
            s=exon[0]
            e=exon[1]
            if s!=self.start:
                startSites.append(s)
            if e!=self.end:
                endSites.append(e)
        return startSites,endSites

    def isStartSplice(self,x):
        if x in self.startSites:
            return True
        return False

    def isEndSplice(self,x):
        if x in self.endSites:
            return True
        return False

    def mergeExon(self,merge):
        tmp=False
        for i in range(len(self.exons)-1):
            if self.exons[i+1][0]-self.exons[i][1]<merge:
                self.exons[i+1]=(self.exons[i][0],self.exons[i+1][1])
                self.exons[i]=(0,0)
                tmp=True
        if tmp:
            c=self.exons.count((0,0))
            for j in range(c):
                self.exons.remove((0,0))
        return

    def convertCigar(self,cigar,merge):
        start=self.start
        end=self.start
        exons=[]
        for i in cigar:
            if i[0]==0:
                end=start+i[1]
                exons.append((start,end-1))
                #if end != start:
                #    exons.append((start,end))
                #else:
                #    exons.append((start,end+1))
                start+=i[1]
            if i[0]==2 or i[0]==3:
                start+=i[1]
                end+=i[1]
        return exons, exons[-1][-1]


