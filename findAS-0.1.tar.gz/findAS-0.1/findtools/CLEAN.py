#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 2011
# GMPF project: Emilio Potenza 2010-2013
#
# Library: Filter function for a single pysam read 
#
#################################################################################
#
###############################################################################
# Imports
###############################################################################

import logging
import operator
import re
global opDiz
global opPattern
global intPattern

logger = logging.getLogger('findtools.CLEAN')

opDiz = {"<":operator.lt, ">":operator.gt, "<=":operator.le,"=<":operator.le, ">=":operator.ge, "=>":operator.ge, "=":operator.eq, "!=":operator.ne}
intPattern = "[-+]{0,1}[0-9]{1,}"
strPattern = "[0-9a-zA-Z_\[\]\\\^\$\.\|\?\*\(\)]{1,}"
#strPattern = "[0-9a-zA-Z_]{1,}"
opPattern = "[!>=<]{1,2}"


###############################################################################
# Filter Def
###############################################################################


def filterINT(observedINT, filters):
    '''
    observedINT = integer
    filters = '>=3,>5,<4' comma separated filter
    '''
    global opDiz
    global opPattern
    global intPattern
    filters = filters.split(",")
    #print filters
    for filter in filters:
        filtINT = int(re.search(intPattern, filter).group())
        filtOP = opDiz[re.search(opPattern, filter).group()]
        #print filters, filtOP, (observedINT,filtINT), filtOP(observedINT,filtINT)
        if not filtOP(observedINT,filtINT):
            return False
    return True


def filterOPT(AlgnRead, filters):
    '''
    AlgnRead = pysam read
    filters = 'XY:>=3,ZT:>5,OPT:<4' comma separated filters
    '''
    global opDiz
    global opPattern
    global intPattern
    filters = filters.split(",")
    #print filters
    for opt_filter in filters:
        opt,filter = opt_filter.split(":")
        try:
            observedINT = int(AlgnRead.opt(opt))
            filtINT = int(re.search(intPattern, filter).group())
            filtOP = opDiz[re.search(opPattern, filter).group()]
            #print "int.", opt,filter,"-",observedINT,filtINT,filtOP(observedINT,filtINT)
            if not filtOP(observedINT,filtINT):
                #print "return false"
                return False
        except KeyError:
            return True
        except ValueError:
            '''string opt'''
            observedSTR = AlgnRead.opt(opt)
            filtSTR = re.search(strPattern, filter).group()
            filtOP = opDiz[re.search(opPattern, filter).group()]
            #print opt,filter,"-",observedSTR,filtSTR, re.search(opPattern, filter).group(), filtOP, filtOP(observedSTR,filtSTR)
            if not filtOP(observedSTR,filtSTR):
                #print "return false"
                return False
    #print "return true"
    return True


def adaptcigar(cigar, gapstep):
        '''from cigar [(0, 25), (1, 1), (0, 59)]
           to [(0, 25), (0, 59)]
           to putative exon [(0, 84)]'''
        if len(cigar) > 1:
            #print cigar, filters
            for n,c in enumerate(cigar):
                if c[0] in [1,2,3] and c[1] < gapstep:
                    cigar.pop(n)
            #print cigar
            new_cigar = [cigar[0]]
            for n in range(len(cigar) - 1):
                if new_cigar[-1][0] == 0 and cigar[n+1][0] == 0:
                    new_cigar[-1] = (0, new_cigar[-1][1] + cigar[n+1][1])
                else:
                    new_cigar.append(cigar[n+1])
            #print new_cigar
            return new_cigar
        else:
            return cigar


def filterEXONside(cigar, filters, gapstep):
    '''
    cigar = ((1,2),(3,4))
    filters = '>=3,>5,<4' comma separated filter
    gapstep = step for exon
    '''

    exons = adaptcigar(cigar, gapstep)
    #print exons
    exons = [exon for exon in exons if exon[0]==0] #only M

    #print filters
    if len(exons) > 1:
        #print exons, exons[0][1], exons[-1][1], filters, filterINT(exons[0][1], filters) and filterINT(exons[-1][1], filters)
        if not (filterINT(exons[0][1], filters) and filterINT(exons[-1][1], filters)):
            return False
    return True


def filterEXONall(cigar, filters, gapstep):
    '''
    cigar = ((1,2),(3,4))
    filters = '>=3,>5,<4' comma separated filter
    gapstep = step for exon
    '''
    exons = adaptcigar(cigar, gapstep)
    bools = True
    for exon in exons:
        if bools and exon[0] == 0: # check M
            bools = bools and filterINT(exon[1], filters)
    return bools


def filterINTRON(cigar, filters, gapstep):
    '''
    cigar = ((1,2),(3,4))
    filters = '>=3,>5,<4' comma separated filter
    gapstep = step for exon
    '''
    exons = adaptcigar(cigar, gapstep)
    bools = True
    for exon in exons:
        if bools and (exon[0] == 2 or exon[0] == 3): # check D and N
            bools = bools and filterINT(exon[1], filters)
    return bools


def main():
    print "[Module] findtools.CLEAN"

if __name__ == '__main__':
    main()
