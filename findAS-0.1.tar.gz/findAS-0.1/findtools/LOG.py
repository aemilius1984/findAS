#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 2012
# GMPF project: Emilio Potenza 2010-2013
#
# Library: generic LOG
#
#################################################################################

###############################################################################
# Imports
###############################################################################


import sys
from os import path as check_path #scared about path variable
from os import access, R_OK, W_OK, X_OK 
import logging
import multiprocessing
import psutil
from time import sleep

logger = logging.getLogger('findtools.LOG')

###############################################################################
# Logging Setup
###############################################################################

def addConsoleHandler(options, l):
    '''
    Set general Logging Level
    and Add Console INFO Logger
    '''
    # Set General Logging Level
    if options.debug:
        l.setLevel(logging.DEBUG)
    else:
        l.setLevel(logging.INFO)

    # create STDOUT handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - [%(levelname)s] - %(message)s','%H:%M:%S')
    ch.setFormatter(formatter)
    l.addHandler(ch)
    return l

def addFileHandler(options, l, filename):
    '''
    Add File Logger
    '''
    # create file handler
    fh = logging.FileHandler(filename)
    if options.debug:
        fh.setLevel(logging.DEBUG)
    else:
        fh.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - [%(levelname)s] - %(message)s','%Y-%m-%d %H:%M:%S')
    fh.setFormatter(formatter)
    l.addHandler(fh)
    return l

###############################################################################
# Input Check
###############################################################################

def wdirCheck(options):
    # Fail-safe check for the working directory
    wdir = check_path.abspath(check_path.expanduser(options.wdir))
    wdir = wdir + "/"
    return wdir

def isFile_executable(path):
    """
    Check if the file is readeble
    """
    if check_path.exists(path):
        if check_path.isfile(path):
            if access(path, X_OK):
                logger.debug("The file %s is executable"%path)
                return True
            else:
                logger.warning("%s is NOT executable!!"%path)
        else:
            logger.warning("%s is NOT a file!!"%path)
    else:
        logger.warning("%s does NOT exist!!"%path)        
    return False

def isFile_readable(path):
    """
    Check if the file is readable
    """
    if check_path.exists(path):
        if check_path.isfile(path):
            if access(path, R_OK):
                logger.debug("The file %s is readable"%path)
                return True
            else:
                logger.warning("%s is NOT readable!!"%path)
        else:
            logger.warning("%s is NOT a file!!"%path)
    else:
        logger.warning("%s does NOT exist!!"%path)        
    return False
            
def isFile_safeOutput(path):
    """
    Check if the file exists, avoid overwrite!
    """
    if check_path.exists(path):
        logger.warning("%s exist, overwrite not allowed!!"%path)
    else:
         return True      
    return False

def isDir_writable(path):
    """
    Check if the dir is writable
    """
    if check_path.exists(path):
        if check_path.isdir(path):
            if access(path, W_OK):
                logger.debug("The directory %s is writable"%path)
                return True
            else:
                logger.warning("%s is NOT writable!!"%path)
        else:
            logger.warning("%s is NOT a directory!!"%path)
    else:
        logger.warning("%s does NOT exist!!"%path)       
    return False


###############################################################################
# Definition and Decorator
###############################################################################


def barPrint(prog, nohup, amount=1):
    '''
    Incrementa di amount il conteggio della barra
    di avanzamento e printa se nohup==False
    prog = ProgresBar
    nohup = True/False
    '''
    if not nohup:
        prog.increment_amount(amount)
        print prog, '\r',
        sys.stdout.flush()
    return


def ramPrint(monitor):
    '''
    ### Print Memory Usage and Statistics
    monitor = myRAMp
    '''
    logger.info("Monitor *x*x*")
    logger.info("Ram Usage (Actual - Max) %s - %s"%(monitor.getMemUsage(), monitor.getMemMax()))
    return


###############################################################################
# Classes
###############################################################################


class myRAMp (multiprocessing.Process):
    '''
    ## RAM monitor ##
    Classe per monitorare la ram usata
    attenzione xche' non ritorna gli errori??!!!
    '''

    def __init__(self, pidi, minAV, n):
        multiprocessing.Process.__init__(self)
        self.p = psutil.Process(pidi)
        self.lock = multiprocessing.Lock()
        arr=[-1 for x in xrange(n)]
        self.pids = multiprocessing.Array("i", arr)
        self.term = False
        self.minAV = minAV
        self.maxp = multiprocessing.Value("f", 0.0) #maxp
        self.maxF = multiprocessing.Value("f", 0.0)
        self.step = 2 # controllo ogni 2 sec

    def run(self):
        '''
        Process Worker
        '''
        try:
            while True:
                try:
                    if self.term:
                        break
                    self.updateFirstPid()
                    tmp=0.0
                    for p in self.pids:
                        try:
                            p=psutil.Process(p)
                            tmp+=float(p.get_memory_percent())
                        except:
                            pass
                    if self.maxp.value < tmp:
                        self.maxp.value = tmp
                    #Ubuntu #CentoS?? tmp>=self.minAV
                    if self.maxF.value >= self.minAV:
                        self.term=True
                    sleep(self.step)
                except KeyboardInterrupt:
                    break
            if tmp >= self.minAV:
                logger.error("Proces ram limit ---\t\t\t\t\n")
                logger.error("Proces ram limit --- EXIT\n")
                self.killMan()
        except KeyboardInterrupt, e:
            ## Stop the current monitor
            logger.error("KeyboardInterrupt")
            logger.error(e)
            self.runStop()
        except Exception, e:
            ## Stop the current monitor
            logger.error("Exception")
            logger.error(e)
            self.runStop()
        finally:
            pass

    def updateFirstPid(self):
        p=psutil.Process(self.pids[0])
        tmp = float(p.get_memory_percent())
        if self.maxF.value<tmp:
            self.maxF.value=tmp
        return

    def getMemUsage(self):
        with self.lock:
            self.updateFirstPid()
            value=0.0
            for p in self.pids:
                try:
                    p=psutil.Process(p)
                    value += float(p.get_memory_percent())
                except:
                    pass
            if self.maxp.value<value:
                self.maxp.value=value
        return value

    def getMemMax(self):
        with self.lock:
            self.updateFirstPid()
            value=0.0
            for p in self.pids:
                try:
                    p=psutil.Process(p)
                    value += float(p.get_memory_percent())
                except:
                    pass
            if self.maxp.value<value:
                self.maxp.value=value
        return self.maxp.value

    def runStop(self):
        self.terminate()

    def killMan(self):
        for p in range(len(self.pids), 0, -1):
            logger.error("kill %s"%(self.pids[p-1]))
            sys.stderr.write()
            try:
                pp=psutil.Process(self.pids[p-1])
                pp.kill()
            except:
                pass
        return


class ProgressBar():
    """
    Semplice Barra di Avanzamento
    usage:
    from progress_bar import ProgressBar
    import sys

    count = 0
    total = 100000

    prog = ProgressBar(count, total, 77, mode='fixed', char='#')
    while count <= total:
        count += 1
        prog.increment_amount()
        print prog, '\r',
        sys.stdout.flush()
    print
    """

    def __init__(self, min_value=0, max_value=100, width=77, **kwargs):
        self.char = kwargs.get('char', '#')
        self.mode = kwargs.get('mode', 'dynamic') # fixed or dynamic
        if not self.mode in ['fixed', 'dynamic']:
            self.mode = 'fixed'
        self.bar = ''
        self.min = min_value
        self.max = max_value
        self.span = max_value - min_value
        self.width = width
        self.amount = 0       # When amount == max, we are 100% done
        self.update_amount(0)

    def increment_amount(self, add_amount=1):
        """
        Increment self.amount by 'add_ammount' or default to incrementing
        by 1, and then rebuild the bar string.
        """
        new_amount = self.amount + add_amount
        if new_amount < self.min:
            new_amount = self.min
        if new_amount > self.max:
            new_amount = self.max
        self.amount = new_amount
        self.build_bar()

    def update_amount(self, new_amount=None):
        """
        Update self.amount with 'new_amount', and then rebuild the bar
        string.
        """
        if not new_amount:
            new_amount = self.amount
        if new_amount < self.min:
            new_amount = self.min
        if new_amount > self.max:
            new_amount = self.max
        self.amount = new_amount
        self.build_bar()

    def build_bar(self):
        """
        Figure new percent complete, and rebuild the bar string base on
        self.amount.
        """
        diff = float(self.amount - self.min)
        percent_done = int(round((diff / float(self.span)) * 100.0))
        # figure the proper number of 'character' make up the bar
        all_full = self.width - 2
        num_hashes = int(round((percent_done * all_full) / 100))
        if self.mode == 'dynamic':
            # build a progress bar with self.char (to create a dynamic bar
            # where the percent string moves along with the bar progress.
            self.bar = self.char * num_hashes
        else:
            # build a progress bar with self.char and spaces (to create a
            # fixe bar (the percent string doesn't move)
            self.bar = self.char * num_hashes + ' ' * (all_full-num_hashes)
        percent_str = str(percent_done) + "%"
        self.bar = ' [' + self.bar + '] ' + percent_str

    def __str__(self):
        return str(self.bar)


def main():
    print "[Module] findtools.LOG"

if __name__ == '__main__':
    main()
