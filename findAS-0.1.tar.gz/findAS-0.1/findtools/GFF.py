#!/usr/bin/env python

# findTools #####################################################################
#
# Author: Emilio Potenza 2011
# GMPF project: Emilio Potenza 2010-2013
#
# Library: GFF3 GTF Iterator
#
#################################################################################
#
###############################################################################
# Imports
###############################################################################

import logging
logger = logging.getLogger('findtools.GFF')


###############################################################################
# Definition
###############################################################################


def writeGFFfromTRANSCRIPT(transcript):
    '''"e%se
MDC011790.825   MDP     gene    14627   17468   .       -       .       ID=MDP0000000999
MDC011790.825   MDP     mRNA    14627   17468   .       -       .       ID=MDP0000000999_mRNA;Parent=MDP0000000999
MDC011790.825   MDP     exon    17318   17468   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    16600   16744   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    16348   16516   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    15803   16073   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    15391   15659   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    15098   15313   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    14806   14914   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
MDC011790.825   MDP     exon    14627   14679   .       -       .       ID=MDP0000000999_exon;Parent=MDP0000000999_mRNA
    '''
    print "%s\tiasma\tgene\t%s\t%s\t.\t-\t.\tID=%s"%(transcript.contig, transcript.start, transcript.end, transcript.id)
    print "%s\tiasam\tmRNA\t%s\t%s\t.\t-\t.\tID=%s_mRNA;Parent=%s"%(transcript.contig, transcript.start, transcript.end, transcript.id, transcript.id)
    for exon in transcript.exons:
        print "%s\tiasma\texon\t%s\t%s\t.\t-\t.\tID=%s_exon;Parent=%s_mRNA"%(transcript.contig, exon[0], exon[1], transcript.id, transcript.id)


###############################################################################
# GFF3 mRNA iteration
###############################################################################

class mRNA_Record():
    '''GFF mRNA'''

    def __init__(self, lines):
        #print lines
        self.lines = lines
        first = lines[0] #0].split()
        self.id = first[8].split("ID=")[1].split(";")[0]
        self.start = int(first[3])
        self.end = int(first[4])
        self.contig = first[0]
        self.strand = first[6]
        self.exons = []
        self.CDSs = []
        self.UTRs = []
        for line in lines:
            #line=line.split()
            if line[2] == "exon":
                self.exons.append((int(line[3]), int(line[4])))
            if line[2] == "CDS":
                self.CDSs.append((int(line[3]), int(line[4])))
            if line[2] in ("UTR", "five_prime_UTR","three_prime_UTR", "five_prime_utr", "three_prime_utr") :
                self.UTRs.append((int(line[3]), int(line[4])))
        self.exons =sorted(self.exons)
        self.CDSs = sorted(self.CDSs)
        self.UTRs = sorted(self.UTRs)
        
        try:
            self.CDSstart = self.CDSs[0][0]
            self.CDSend = self.CDSs[-1][-1]
            ###
            # check format integrity
            struct = self.CDSs + self.UTRs
            struct = sorted(struct)
            s = struct[0][0]
            e = struct[-1][-1]
            if s != self.start or e != self.end:
                logger.debug("CDS+UTR start-end WARNING in mRNA %s"%self.id)
                self.start = min([s,self.start])
                self.end = max([e,self.end])
        except Exception as e:
            logger.error(e)
            #print self.id
            
        
            
        
                
        ###
        
    def getJunctions(self):
        struct = self.getStructure()
        edges = []
        if struct > 1:
            for e in range(len(struct)-1):
                edges.append((struct[e][1], struct[e+1][0]))
        return edges
    
    def getStructure(self):
        '''
        return exons list from CDS and UTR
        '''
        struct = self.CDSs + self.UTRs
        struct = sorted(struct)
        merge = True
        while merge:
            structure = []
            merge = False
            for p,exon in enumerate(struct[:-1]):
                if exon[1] +1 == struct[p+1][0]:
                    for n,e in enumerate(struct):
                        if n == p:
                            structure.append((exon[0], struct[p+1][1]))
                        elif n == p+1:
                            pass
                        else:
                            structure.append(e)
                    merge = True
                    struct = structure
                    break
        return struct
            

def gff_itr(src):
    """Provide an iteration through the mRNA records in file `src'.
    Here `src' can be either a file object or the name of a file.
    """
    if type(src) == str:
        return _mRNA_itr_from_name_gff(src)
    elif type(src) == file:
        return _mRNA_itr_from_file_gff(src)
        '''elif type(src) == list: return _mRNA_itr_from_file_gff(src);'''
    else:
        raise TypeError

gff_itr_mRNA = gff_itr
"""
Change name gff_itr ---> gff_itr_mRNA
Provide an iteration through the mRNA records in file `src'.
Here `src' can be either a file object or the name of a file.
"""

def _mRNA_itr_from_file_gff(file):
    "Provide an iteration through the mRNA records in gff file."
    lines = []
    for line in file:
        if line[0]!="#":
            line = line.strip()
            #print line
            line = line.split()
            if line[2] != "chromosome" and line[2] != "gene":
                if line[2] == 'mRNA':
                    if lines != []:
                        mRNA = mRNA_Record(lines)
                        if mRNA.id[-2:]==".1" or mRNA.id[-4:]==".t01":
                            yield mRNA
                        else:
                            lines = [line]
                            continue
                    lines = [line]
                    continue
                lines += [line]
    mRNA = mRNA_Record(lines)
    if mRNA.id[-2:]==".1" or mRNA.id[-4:]==".t01":
        yield mRNA


def _mRNA_itr_from_name_gff(fname):
    "Provide an iteration through the mRNA records in the gff file named fname. "
    f = open(fname)
    for rec in _mRNA_itr_from_file_gff(f):
        yield rec
    f.close()


###############################################################################
# GFF3 gene iteration
###############################################################################

class gene_Record():
    '''GFF gene'''

    def __init__(self, lines):
        first = lines[0]
        self.id = first[8].split("ID=")[1].split(";")[0]
        self.start = int(first[3])
        self.end = int(first[4])
        self.contig = first[0]
        self.strand = first[7]
        self.mRNAs = []
        lines = ["\t".join(line) for line in lines]
        for mRNA in gff_itr_mRNA(lines):
            self.mRNAs.append(mRNA)

def gff_itr_gene(src):
    """Provide an iteration through the mRNA records in file `src'.
    Here `src' can be either a file object or the name of a file.
    """
    if type(src) == str:
        return _gene_itr_from_name_gff(src)
    elif type(src) == file:
        return _gene_itr_from_file_gff(src)
    else:
        raise TypeError

def _gene_itr_from_file_gff(file):
    "Provide an iteration through the gene records in gff file."
    lines = []
    for line in file:
        if line[0]!="#":
            line = line.strip()
            #print line
            line = line.split()
            if line[2] != "chromosome": #and line[2] != "gene":
                if line[2] == 'gene':
                    if lines != []:
                        yield gene_Record(lines)
                    lines = [line]
                    continue
                lines += [line]
    yield gene_Record(lines)


def _gene_itr_from_name_gff(fname):
    "Provide an iteration through the gene records in the gff file named fname. "
    f = open(fname)
    for rec in _gene_itr_from_file_gff(f):
        yield rec
    f.close()


###############################################################################
# GTF cufflinks based for transcript iteration
###############################################################################

class transcript_Record():
    '''GTF transcript'''

    def __init__(self, lines):
        #print lines
        first = lines[0] #].split()
        self.id = first[11][1:-2]  #  [8].split("ID=")[1].split(";")[0] for gff #[11][1:-2] for gtf
        #print self.id
        self.start = int(first[3])
        self.end = int(first[4])
        self.contig = first[0]
        self.strand = first[7]
        self.exons = []
        self.CDSs = []
        for line in lines:
            #line=line.split()
            if line[2] == "exon":
                self.exons.append((int(line[3]), int(line[4])))
            if line[2] == "CDS":
                self.CDSs.append((int(line[3]), int(line[4])))
        #print self.id,self.start,self.end,self.contig
        #print self.exons

def _transcript_itr_from_file_gtf(file):
    "Provide an iteration through the transcript records in gff file."
    lines = []
    for line in file:
        if line[0]!="#":
            line = line.split()
            if line[2] != "chromosome" and line[2] != "gene":
                if line[2] == 'transcript':      #"transcript for gtf #mRNA
                    if lines != []:
                        yield transcript_Record(lines)
                    lines = [line]
                    continue
                lines += [line]
    yield transcript_Record(lines)


def _transcript_itr_from_name_gtf(fname):
    "Provide an iteration through the transcript records in the gff file named fname. "
    f = open(fname)
    for rec in _transcript_itr_from_file_gtf(f):
        yield rec
    f.close()


def gtf_itr(src):
    """Provide an iteration through the mRNA records in file `src'.
    Here `src' can be either a file object or the name of a file.
    """
    if type(src) == str:
        return _transcript_itr_from_name_gtf(src)
    elif type(src) == file:
        return _transcript_itr_from_file_gtf(src)
    else:
        raise TypeError


def main():
    print "[Module] findtools.GFF GTF GFF3 iteration module"

if __name__ == '__main__':
    main()

