from distutils.core import setup


__version__ ='0.1'
### Change also __init__.py in findtools dir
### Change also conf.py 

setup(
    name = 'findAS',
    version = __version__,
    author = 'Emilio Potenza',
    author_email = 'emilio.potenza@gmail.com',
    packages = ['findtools'], #, "findtools.test"],
    scripts = ['bin/findAS', "bin/statAS"],  
    url = 'https://github.com/aemilius1984/findAS.git', 
    license = 'LICENSE.txt',
    description = 'Useful ngs-related stuff',
    long_description = open('README.txt').read(),
    install_requires = ["pysam >= 0.6", "psutil >= 0.4.1", "numpy >= 1.6.1"]
)



